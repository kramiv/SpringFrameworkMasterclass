package com.in28minutes_springboot.in28minutes_demo.basic;

public interface SortAlgorithm {
	public int[] sort(int[] numbers);
}
