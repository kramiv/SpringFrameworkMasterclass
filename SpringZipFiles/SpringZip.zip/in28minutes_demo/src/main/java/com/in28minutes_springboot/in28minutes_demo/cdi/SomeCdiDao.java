package com.in28minutes_springboot.in28minutes_demo.cdi;

import javax.inject.Named;

import org.springframework.stereotype.Component;

@Named
public class SomeCdiDao {

}
