package com.in28minutes_springboot.in28minutes_demo.xml;

public class XmlJdbcConnection {
	public XmlJdbcConnection() {
		System.out.println("JDBC Connection");
	}
	
	
	
}
